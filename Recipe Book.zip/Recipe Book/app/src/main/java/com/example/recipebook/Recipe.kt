package com.example.recipebook

import java.sql.Blob

class Recipe (val id : Int, val name: String, val image: ByteArray, val ingredients: String, val recipe: String){
}