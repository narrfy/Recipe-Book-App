package com.example.recipebook

import android.content.Intent
import android.graphics.ColorSpace
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.startActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.recipebook.Model.Companion.recipes
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

class AllRecipes : AppCompatActivity(), RecipeAdapter.ItemAdapterListener {

    private lateinit var recyclerView: RecyclerView
    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var adapter: RecipeAdapter
    private lateinit var recipeList: MutableList<Recipe>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_all_recipes)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        databaseHelper = DatabaseHelper(this)
        recipeList = mutableListOf()

        val cursor = databaseHelper.getAllItems()

        while (cursor.moveToNext()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow("_id"))
            val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
            val image = cursor.getBlob(cursor.getColumnIndexOrThrow("image"))
            val ingredients = cursor.getString(cursor.getColumnIndexOrThrow("ingredients"))
            val recipe = cursor.getString(cursor.getColumnIndexOrThrow("recipe"))
            recipeList.add(Recipe(id, name, image, ingredients, recipe))

        }

        // Setup RecyclerView
        recyclerView = findViewById(R.id.allRecipeRecyclerView)
        adapter = RecipeAdapter(this, recipeList, this)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
    }

    override fun onDelete(position: Int) {
        val recipe = recipeList[position]
        databaseHelper.deleteItem(recipe.id)
        recipeList.removeAt(position)
        adapter.updateRecipes(recipeList)
    }

    // https://medium.com/@sujitpanda/file-read-write-with-kotlin-io-31eff564dfe3 - Talks about how to use File IO in kotlin
    override fun onShare(recipe: Recipe) {
        val fileName = "shared_recipe.txt"
        val file = File(this.filesDir, fileName)

        try {
            FileOutputStream(file).use { outputStream ->
                val recipeData = "Recipe Name: ${recipe.name}\n" + "Ingredients: ${recipe.ingredients}\n" + "Recipe: ${recipe.recipe}\n"
                outputStream.write(recipeData.toByteArray())
                outputStream.flush()
            }
            Toast.makeText(this, "Recipe successfully moved, you can now share", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to share recipe :(", Toast.LENGTH_SHORT).show()
        }

    }


    override fun onClick(position: Int) {
        val recipe = recipeList[position]
        val intent = Intent(this, NewRecipe::class.java).apply {
            putExtra("ID", recipe.id)
        }
        startActivity(intent)
    }
}
