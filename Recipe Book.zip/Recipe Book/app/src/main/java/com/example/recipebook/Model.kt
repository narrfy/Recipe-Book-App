package com.example.recipebook

class Model {
    companion object {
        val recipes = mutableListOf<Recipe>()

        fun add(recipe: Recipe) {
            recipes.add(recipe)
        }
    }
}