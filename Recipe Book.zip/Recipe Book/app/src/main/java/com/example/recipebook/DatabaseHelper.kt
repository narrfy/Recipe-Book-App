package com.example.recipebook

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import java.io.ByteArrayOutputStream

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private const val DATABASE_NAME = "items.db"
        private const val DATABASE_VERSION = 1
    }

    // Create the table
    override fun onCreate(db: SQLiteDatabase) {
        val query = """
            CREATE TABLE recipe(
            _id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            image BLOB,
            ingredients TEXT NOT NULL,
            recipe TEXT NOT NULL
            );
        """.trimIndent()
        db.execSQL(query)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {

    }

    // Add item
    fun insertItem(name: String, image: ByteArray, ingredients : String, recipe: String): Boolean {
        val db = this.writableDatabase
        val itemValues = ContentValues().apply {
            put("name", name)
            put("image", image)
            put("ingredients", ingredients)
            put("recipe", recipe)
        }
        db.insert("recipe", null, itemValues)
        db.close()
        return true
    }

    // Delete item
    fun deleteItem(id: Int) {
        val db = this.writableDatabase
        db.delete("recipe", "_id = ?", arrayOf(id.toString()))
        db.close()
    }

    // Query All
    fun getAllItems(): Cursor {
        val db = this.readableDatabase
        val cursor = db.query(
            "recipe",
            arrayOf("_id", "name", "image", "ingredients", "recipe"),
            null,
            null,
            null,
            null,
            null,
            null
        )
        Log.d("DB HELPER", "Got all items")
        return cursor
    }

    // Query Specific items
    fun getSpecificItem(number: Int): Cursor {
        val db = this.readableDatabase
        val cursor = db.query(
            "recipe",
            arrayOf("_id", "name", "image", "ingredients", "recipe"),
            "_id = ?",
            arrayOf(number.toString()),
            null,
            null,
            null,
            null
        )
        Log.d("DB HELPER", "Got specific item")
        return cursor
    }

}