package com.example.recipebook

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private var recipeID : Int = 0

    private lateinit var nameTextView : TextView
    private lateinit var imageView: ImageView
    private lateinit var ingredientsTextView : TextView

    private lateinit var toolbar: Toolbar

    private var frame : FrameLayout ?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Initialize toolbar
        toolbar = findViewById(R.id.mainToolbar)
        setSupportActionBar(toolbar)

        // Initialize DB
        databaseHelper = DatabaseHelper(this)

        // Setup different layouts
        val work = supportFragmentManager.findFragmentById(R.id.fragmentContainerView) as? InformationFragment

        if (work != null) {
            frame = findViewById(R.id.frameLayout)

            if (frame != null) {
                val recipeFragment = RecipeFragment()
                val informationFragment = InformationFragment()

                recipeFragment.setRecipeID(recipeID)
                informationFragment.setRecipeID(recipeID)
                informationFragment.setLayoutID(1)

                val ft = supportFragmentManager.beginTransaction()
                ft.replace(R.id.frameLayout, recipeFragment)
                ft.commit()
            }
        }


    }

    // Show a single recipe (button click)
    fun showRecipe(view: View){
        val intent = Intent(applicationContext, RecipeActivity::class.java)
        intent.putExtra("ID", recipeID)
        startActivity(intent)
    }

    // Inflate menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }


    // Setup menu buttons
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.addNew -> { // addNew - Take to NewRecipe
                val intent = Intent(this, NewRecipe::class.java)
                startActivity(intent)
                true
            }
            R.id.showAll -> { // showAll - Take to AllRecipes
                val intent = Intent(this, AllRecipes::class.java)
                startActivity(intent)
                true
            }
            R.id.random -> { // random - Show a random recipe from DB
                val cursor = databaseHelper.getAllItems()

                if (cursor.count > 0) {
                    val randomIndex = (0 until cursor.count).random()
                    if (cursor.moveToPosition(randomIndex)) {
                        recipeID = cursor.getInt(cursor.getColumnIndexOrThrow("_id"))

                        val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                        val ingredients = cursor.getString(cursor.getColumnIndexOrThrow("ingredients"))

                        val image = cursor.getBlob(cursor.getColumnIndexOrThrow("image"))


                        nameTextView = findViewById(R.id.mainRecipeNameTextView)
                        imageView = findViewById(R.id.mainImageView)
                        ingredientsTextView = findViewById(R.id.mainIngredientsTextView)

                        if (image != null) {
                            val bitmapImage = BitmapFactory.decodeByteArray(image, 0, image.size)
                            imageView.setImageBitmap(bitmapImage)
                        }

                        nameTextView.text = name
                        ingredientsTextView.text = ingredients

                    }
                } else {
                    Toast.makeText(this, "No recipes found", Toast.LENGTH_SHORT).show()
                }
                true
            }
            R.id.update -> { // update - Take to NewRecipe, Give DB position to show all info
                val intent = Intent(this, NewRecipe::class.java)
                val cursor = databaseHelper.getAllItems()

                if (cursor.count > 0) {
                    cursor.moveToPosition(recipeID - 1)
                    val recipeId = cursor.getInt(cursor.getColumnIndexOrThrow("_id"))

                    intent.putExtra("ID", recipeId)
                    startActivity(intent)
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}