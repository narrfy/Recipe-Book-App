package com.example.recipebook

import android.annotation.SuppressLint
import android.content.Intent
import android.database.Cursor
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class InformationFragment : Fragment() {

    private var recipeID : Int = 0
    private var layoutID : Int = 0

    private lateinit var dbHelper: DatabaseHelper

    private lateinit var nameTextView : TextView
    private lateinit var imageView : ImageView
    private lateinit var ingredientsTextView : TextView
    private lateinit var makeButton : Button

    @SuppressLint("Range")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_information, container, false)

        dbHelper = DatabaseHelper(requireContext())
        val cursor: Cursor = dbHelper.getSpecificItem(recipeID)

        nameTextView = view.findViewById(R.id.mainRecipeNameTextView)
        imageView = view.findViewById(R.id.mainImageView)
        ingredientsTextView = view.findViewById(R.id.mainIngredientsTextView)
        makeButton = view.findViewById(R.id.mainMakeButton)


        if (cursor.moveToFirst()) {
            val name = cursor.getString(cursor.getColumnIndex("name"))
            val image = cursor.getBlob(cursor.getColumnIndex("image"))
            val ingredients =  cursor.getString(cursor.getColumnIndex("ingredients"))

            nameTextView.text = name
            ingredientsTextView.text = ingredients

            if (image != null) {
                val bitmap = BitmapFactory.decodeByteArray(image, 0, image.size)
                imageView.setImageBitmap(bitmap)
            }
        }

        makeButton.setOnClickListener {
            val intent = Intent(activity, RecipeActivity::class.java)
            intent.putExtra("ID", recipeID)
            startActivity(intent)
        }

        cursor.close()
        return view
    }


    fun setRecipeID(recipeID : Int){
        this.recipeID = recipeID
    }

    fun setLayoutID(layoutID : Int) {
        this.layoutID = layoutID
        makeButton.visibility = View.GONE

    }

}