package com.example.recipebook

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView


class RecipeAdapter(
    private val context: Context,
    private var recipes: MutableList<Recipe>,
    private val listener: ItemAdapterListener
) : RecyclerView.Adapter<RecipeAdapter.ViewHolder>() {

    interface ItemAdapterListener {
        fun onDelete(position: Int)
        fun onShare(recipe: Recipe)
        fun onClick(position: Int)
    }

    class ViewHolder(itemView: View, private val listener: ItemAdapterListener) : RecyclerView.ViewHolder(itemView) {
        private var nameTextView: TextView = itemView.findViewById(R.id.recipeViewNameTextView)
        private var imageView: ImageView = itemView.findViewById(R.id.recipeViewImageView)
        private var shareButton: Button = itemView.findViewById(R.id.recipeViewShareButton)
        private var deleteButton: Button = itemView.findViewById(R.id.recipeViewDeleteButton)

        fun update(recipe: Recipe, position: Int) {
            nameTextView.text = recipe.name
            recipe.image.let {
                val bitmap = BitmapFactory.decodeByteArray(it, 0, it.size)
                imageView.setImageBitmap(bitmap)
            }

            shareButton.setOnClickListener {
                listener.onShare(recipe)
            }

            deleteButton.setOnClickListener {
                listener.onDelete(position)
            }

            itemView.setOnClickListener {
                listener.onClick(position)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recipe_view, parent, false)
        return ViewHolder(view, listener)
    }

    override fun getItemCount(): Int {
        return recipes.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val recipe = recipes[position]
        holder.update(recipe, position)
    }

    // Update the recipe list and refresh RecyclerView
    fun updateRecipes(newRecipes: MutableList<Recipe>) {
        recipes = newRecipes
        notifyDataSetChanged()
    }
}
