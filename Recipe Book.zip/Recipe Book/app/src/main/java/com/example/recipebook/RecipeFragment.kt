package com.example.recipebook

import android.annotation.SuppressLint
import android.database.Cursor
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

class RecipeFragment : Fragment() {

    private lateinit var recipeTextView : TextView
    private var recipeID : Int = 0

    @SuppressLint("Range")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view = inflater.inflate(R.layout.fragment_recipe, container, false)

        recipeTextView = view.findViewById(R.id.recipeFragmentRecipeTextView)

        val dbHelper = DatabaseHelper(requireContext())
        val cursor: Cursor = dbHelper.getSpecificItem(recipeID)

        if (cursor.moveToFirst()) {
            val recipe = cursor.getString(cursor.getColumnIndex("recipe"))
            recipeTextView.text = recipe
        }

        cursor.close()
        return view
    }


    fun setRecipeID(recipeID : Int){
        this.recipeID = recipeID
    }

}